package com.example.gpayapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
