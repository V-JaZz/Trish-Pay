import 'dart:async';
import 'package:get/get.dart';
import 'package:gpayapp/OnBoardingScreen/onboarding_screen.dart';

class SplashController extends GetxController{
  @override
  void onInit() {
    Timer(
      Duration(seconds: 6),
          () =>
          Get.off(OnBoardingScreen()),
    );
    super.onInit();
  }
}