import 'package:get/get.dart';

class RoutController extends GetxController{
  var pageIndex = 0.obs;
}