import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:gpayapp/ProfileScreen/PaymentMethodScreen/payment_methd_screen.dart';
import 'package:gpayapp/ProfileScreen/PaymentMethodScreen/select_bank_screen.dart';
import 'package:gpayapp/ProfileScreen/setting_screen.dart';
import 'package:gpayapp/ScannerScreen/show_qrcode_screen.dart';
import 'package:gpayapp/Utils/colors.dart';
import 'package:gpayapp/Utils/common_widget.dart';
import 'package:gpayapp/Utils/images.dart';
import 'package:gpayapp/main.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key}) : super(key: key);

  final List<Map> paymentMethodList = [
    {
      "image": Images.paymentCard1,
    },
    {
      "image": Images.paymentCard2,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.white,
      body: Padding(
        padding: EdgeInsets.only(top: 60, left: 20, right: 20),
        child: ScrollConfiguration(
          behavior: MyBehavior(),
          child: SingleChildScrollView(
            child: Column(
              children: [
                boldText("Profile", ColorResources.black, 20),
                SizedBox(height: 18),
                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 2),
                  child: Container(
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: ColorResources.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 2,
                          spreadRadius: 0,
                          offset: Offset(0, 0),
                          color: ColorResources.black.withOpacity(0.25),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: Stack(
                            children: [
                              CircleAvatar(
                                radius: 35,
                                backgroundImage: AssetImage(Images.johnDeo),
                              ),
                              Positioned(
                                  top: 20,
                                  left: 40,
                                  child: InkWell(
                                    onTap: (){
                                      Get.to(ShowQrCodeScreen());
                                    },
                                    child: Image.asset(Images.qrCodeImage,
                                        height: 40, width: 40),
                                  )),
                            ],
                          ),
                          contentPadding: EdgeInsets.only(top: 15, left: 10),
                          title: boldText("John Doe", ColorResources.blue1D3, 20),
                          subtitle: regularText(
                              "+91 12345 67890", ColorResources.grey6B7, 14),
                        ),
                        SizedBox(height: 15),
                        Container(
                          height: 40,
                          width: Get.width,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(14),
                              bottomRight: Radius.circular(14),
                            ),
                            color: ColorResources.greyF9F,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(Images.rewardsEarnedImage),
                              SizedBox(width: 10),
                              boldText("₹ 182", ColorResources.blue1D3, 16),
                              SizedBox(width: 6),
                              regularText(
                                  "Rewards Earned", ColorResources.grey6B7, 12),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 2),
                  child: Container(
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: ColorResources.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 2,
                          spreadRadius: 0,
                          offset: Offset(0, 0),
                          color: ColorResources.black.withOpacity(0.25),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 15),
                        Padding(
                          padding: EdgeInsets.only(left: 15, right: 15),
                          child: boldText(
                              "Payment Methods", ColorResources.blue1D3, 18),
                        ),
                        SizedBox(height: 10),
                        Padding(
                          padding: EdgeInsets.only(left: 15, right: 15),
                          child: regularText(
                              "Bank Accounts", ColorResources.grey6B7, 14),
                        ),
                        SizedBox(height: 10),
                        SizedBox(
                          height: 130,
                          width: Get.width,
                          child: ScrollConfiguration(
                            behavior: MyBehavior(),
                            child: ListView.builder(
                              padding: EdgeInsets.only(left: 15, right: 5),
                              shrinkWrap: true,
                              itemCount: paymentMethodList.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, index) => Padding(
                                padding: EdgeInsets.only(right: 10),
                                child: InkWell(
                                  onTap: () {
                                    Get.to(Get.to(SelectBankScreen()));
                                  },
                                  child: Container(
                                    height: 130,
                                    width: 222,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      image: DecorationImage(
                                        image: AssetImage(
                                            paymentMethodList[index]["image"]),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        InkWell(
                          onTap: () {
                            Get.to(PaymentMethodScreen());
                          },
                          child: Container(
                            height: 40,
                            width: Get.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(14),
                                bottomRight: Radius.circular(14),
                              ),
                              color: ColorResources.whiteE1E,
                            ),
                            child: Center(
                              child: mediumText("View All Payment Methods  >",
                                  ColorResources.blue1D3, 14),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    SvgPicture.asset(Images.gift),
                    SizedBox(width: 13),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        boldText("Invite friends, get rewards",
                            ColorResources.blue1D3, 12),
                        SizedBox(height: 6),
                        Row(
                          children: [
                            regularText(
                                "Share this code", ColorResources.grey6B7, 12),
                            SizedBox(width: 5),
                            boldText("abcd5j", ColorResources.blue1D3, 12),
                            SizedBox(width: 5),
                            Icon(Icons.copy,
                                color: ColorResources.blue1D3, size: 15),
                          ],
                        ),
                      ],
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: boldText("Share", ColorResources.green1B7, 14),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 30),
                InkWell(
                  onTap: () {
                    Get.to(SettingScreen());
                  },
                  child: Row(
                    children: [
                      SvgPicture.asset(Images.settings),
                      SizedBox(width: 15),
                      mediumText("Settings", ColorResources.blue1D3, 16),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    SvgPicture.asset(Images.help),
                    SizedBox(width: 15),
                    mediumText("Help and feedback", ColorResources.blue1D3, 16),
                  ],
                ),
                SizedBox(height: 130),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
