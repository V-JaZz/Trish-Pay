import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:gpayapp/HomeScreen/ElectricityBillScreens/all_electricity_billers_screen2.dart';
import 'package:gpayapp/Utils/colors.dart';
import 'package:gpayapp/Utils/common_widget.dart';
import 'package:gpayapp/Utils/images.dart';
import 'package:gpayapp/main.dart';

class AllElectriCityBillersScreen extends StatelessWidget {
  AllElectriCityBillersScreen({Key? key}) : super(key: key);

  final List<Map> billersInGujaratList = [
    {
      "image":Images.bill1,
      "text": "DGVCL Dakshin Gujarat Vij",
    },
    {
      "image":Images.bill2,
      "text": "Gift Power Company Limited",
    },
    {
      "image":Images.bill3,
      "text": "MGVCL Madhya Gujarat Vij",
    },
    {
      "image":Images.bill4,
      "text": "PGVCL Paschim Gujarat Vij",
    },
    {
      "image":Images.bill5,
      "text": "Torrent Power",
    },
    {
      "image":Images.bill6,
      "text": "UGVCL Uttar Gujarat Vij",
    },
  ];

  final List<Map> allBillersList = [
    {
      "image":Images.allBill1,
      "text": "APSPDCL AP South",
    },
    {
      "image":Images.allBill2,
      "text": "Adani Electricity Mumbai Limited",
    },
    {
      "image":Images.allBill3,
      "text": "Ajmer Vidyut Vitran Nigam Ltd",
    },
    {
      "image":Images.allBill4,
      "text": "Assam Power Distribution Company Ltd\n(Rural)",
    },
    {
      "image":Images.allBill5,
      "text": "BESCOM Bangalore",
    },
    {
      "image":Images.allBill6,
      "text": "BESL Bharatpur Electricity Services Ltd",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.white,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: ColorResources.white,
        automaticallyImplyLeading: false,
        centerTitle: true,
        elevation: 0,
        leading: Padding(
          padding: EdgeInsets.only(left: 18,top: 8,bottom: 8),
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: ColorResources.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ColorResources.greyE5E, width: 1),
              ),
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_outlined,
                  color: ColorResources.black,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: boldText("All Electricity billers", ColorResources.black, 20),
      ),
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: textField("Search by biller", Images.search),),
              SizedBox(height: 20),
              Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: boldText(
                    "Billers in Gujarat", ColorResources.grey6B7, 20),),
              SizedBox(height: 18),
              ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: billersInGujaratList.length,
                itemBuilder: (context, index) =>
                    Padding(
                      padding:  EdgeInsets.only(bottom: 20),
                      child: Column(
                        children: [
                          InkWell(
                            onTap:(){
                              Get.to(AllElectricityBillersScreen2());
                            },
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 25,
                                backgroundImage: AssetImage(
                                  billersInGujaratList[index]["image"],),
                              ),
                              title: mediumText(billersInGujaratList[index]["text"],
                                  ColorResources.blue1D3, 14),
                            ),
                          ),
                          SizedBox(height: 10),
                          Divider(thickness: 1, color: ColorResources.greyF3F),
                        ],
                      ),
                    ),
              ),
              Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: boldText(
                    "All Billers", ColorResources.grey6B7, 20),),
              SizedBox(height: 18),
              ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: allBillersList.length,
                itemBuilder: (context, index) =>
                    Padding(
                      padding:  EdgeInsets.only(bottom: 10),
                      child: Column(
                        children: [
                          ListTile(
                            leading: CircleAvatar(
                              radius: 25,
                              backgroundImage: AssetImage(
                                allBillersList[index]["image"],),
                            ),
                            title: mediumText(allBillersList[index]["text"],
                                ColorResources.blue1D3, 14),
                          ),
                          SizedBox(height: 10),
                          Divider(thickness: 1, color: ColorResources.greyF3F),
                        ],
                      ),
                    ),
              ),
              SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }
}
