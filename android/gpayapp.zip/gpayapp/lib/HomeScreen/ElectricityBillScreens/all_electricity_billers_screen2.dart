import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:gpayapp/HomeScreen/ElectricityBillScreens/electricity_bill_payment_screen.dart';
import 'package:gpayapp/Utils/colors.dart';
import 'package:gpayapp/Utils/common_widget.dart';

class AllElectricityBillersScreen2 extends StatelessWidget {
  AllElectricityBillersScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.white,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: ColorResources.white,
        automaticallyImplyLeading: false,
        centerTitle: true,
        elevation: 0,
        leading: Padding(
          padding: EdgeInsets.only(left: 18,top: 8,bottom: 8),
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: ColorResources.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ColorResources.greyE5E, width: 1),
              ),
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_outlined,
                  color: ColorResources.black,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: boldText("DGVCL Dakshin Guja...", ColorResources.black, 20),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 25, bottom: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            textField1("Consumer Number"),
            SizedBox(height: 10),
            regularText("Please enter valid Consumer Number like 10859020916",
                ColorResources.grey9CA, 12),
            Spacer(),
        InkWell(
          onTap: (){
            Get.to(ElectricityBillPaymentScreen());
          },
          child: Container(
            height: 52,
            width: Get.width,
            decoration: BoxDecoration(
              color: ColorResources.greyC1C,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Center(
              child: boldText("Confirm", ColorResources.white, 16),
            ),
          ),
        ),
          ],
        ),
      ),
    );
  }
}
