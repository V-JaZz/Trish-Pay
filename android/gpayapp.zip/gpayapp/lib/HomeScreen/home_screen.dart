import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:gpayapp/HomeScreen/ElectricityBillScreens/all_electrycity_billers_screen.dart';
import 'package:gpayapp/HomeScreen/BankBalanceScreen/bank_balance_screen.dart';
import 'package:gpayapp/HomeScreen/GooglePlayScreen/google_play_screen.dart';
import 'package:gpayapp/HomeScreen/PromotionScreen/VoucherScreen/voucher_screen.dart';
import 'package:gpayapp/HomeScreen/PromotionScreen/offers_screen.dart';
import 'package:gpayapp/HomeScreen/PromotionScreen/referrals_screen.dart';
import 'package:gpayapp/HomeScreen/PromotionScreen/RewardsScreen/rewards_screen.dart';
import 'package:gpayapp/HomeScreen/ViewMoreScreens/business_bills_screen.dart';
import 'package:gpayapp/HomeScreen/EnterMobileNumber&RecipientScreens/enter_mobilenumber_screen.dart';
import 'package:gpayapp/HomeScreen/EnterMobileNumber&RecipientScreens/enter_recipient_screen.dart';
import 'package:gpayapp/HomeScreen/MobileRechargeScreen/mobile_recharge_screen.dart';
import 'package:gpayapp/HomeScreen/ChatScreens/chat_screen2.dart';
import 'package:gpayapp/HomeScreen/ViewMoreScreens/payment_categories_screen.dart';
import 'package:gpayapp/HomeScreen/ViewMoreScreens/people_screen.dart';
import 'package:gpayapp/HomeScreen/SelectProviderBillScreens/select_provider_screen.dart';
import 'package:gpayapp/HomeScreen/SelfTransferScreen/self_transfer_screen.dart';
import 'package:gpayapp/NotificationsScreen/notification_screen.dart';
import 'package:gpayapp/ScannerScreen/scan_qrcode_screen.dart';
import 'package:gpayapp/Search_Screen/search_screen.dart';
import 'package:gpayapp/Utils/colors.dart';
import 'package:gpayapp/Utils/common_widget.dart';
import 'package:gpayapp/Utils/images.dart';
import 'package:gpayapp/main.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);

  final List<Map> paymentCategoryList = [
    {
      "image": Images.mobileRechargeImage,
      "text": "Mobile\nrecharge",
      "onTap": () {
        Get.to(MobileRechargeScreen());
      },
    },
    {
      "image": Images.electricityImage,
      "text": "Electricity",
      "onTap": () {
        Get.to(AllElectriCityBillersScreen());
      },
    },
    {
      "image": Images.monitorImage,
      "text": "DTH",
      "onTap": () {
        Get.to(SelectProviderScreen());
      },
    },
    {
      "image": Images.fastagRecharge,
      "text": "FASTag\nrecharge",
      "onTap": () {
        Get.to(AllElectriCityBillersScreen());
      },
    },
    {
      "image": Images.googlePlayImage,
      "text": "Google\nPlay",
      "onTap": () {
        Get.to(GooglePlayScreen());
      },
    },
    {
      "image": Images.card,
      "text": "Credit\nCard Bill",
      "onTap": () {
        Get.to(AllElectriCityBillersScreen());
      },
    },
    {
      "image": Images.cylinderImage,
      "text": "Book A\nCylinder",
      "onTap": () {
        Get.to(AllElectriCityBillersScreen());
      },
    },
    {
      "image": Images.addImage,
      "text": "+ More",
      "onTap": () {
        Get.to(PaymentCategoriesScreen());
      },
    },
  ];

  final List<Map> peopleList = [
    {
      "image": Images.jenny,
      "text": "Jenny",
      "onTap": () {
        Get.to(ChatScreen2());
      },
    },
    {
      "image": Images.bessie,
      "text": "Bessie",
      "onTap": () {
        Get.to(ChatScreen2());
      },
    },
    {
      "image": Images.jacob,
      "text": "Jacob",
      "onTap": () {
        Get.to(ChatScreen2());
      },
    },
    {
      "image": Images.darlene,
      "text": "Darlene",
      "onTap": () {
        Get.to(ChatScreen2());
      },
    },
    {
      "image": Images.addPng,
      "text": "+ More",
      "onTap": () {
        Get.to(PeopleScreen());
      },
    },
  ];

  final List<Map> businessAndBillsList = [
    {
      "image": Images.redBus,
      "text": "redBus",
      "onTap": () {},
    },
    {
      "image": Images.makeMyTrip,
      "text": "MakeMyTrip",
      "onTap": () {},
    },
    {
      "image": Images.tataSky,
      "text": "Tata Sky",
      "onTap": () {},
    },
    {
      "image": Images.yatra,
      "text": "Yatra",
      "onTap": () {},
    },
    {
      "image": Images.barista,
      "text": "Barista",
      "onTap": () {},
    },
    {
      "image": Images.macDonalds,
      "text": "Mcdonald’S",
      "onTap": () {},
    },
    {
      "image": Images.zomato,
      "text": "Zomato",
      "onTap": () {},
    },
    {
      "image": Images.addPng,
      "text": "+ More",
      "onTap": () {
        Get.to(BusinessAndBillsScreen());
      },
    },
  ];

  final List<Map> promotionList = [
    {
      "image": Images.rewardImage,
      "text": "Reward",
      "onTap": () {
        Get.to(RewardsScreen());
      },
    },
    {
      "image": Images.offersImage,
      "text": "Offers",
      "onTap": () {
        Get.to(OffersScreen());
      },
    },
    {
      "image": Images.referralsImage,
      "text": "Referrals",
      "onTap": () {
        Get.to(ReferralsScreen());
      },
    },
    {
      "image": Images.voucherImage,
      "text": "Voucher",
      "onTap": () {
        Get.to(VoucherScreen());
      },
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.white,
      body: Stack(
        children: [
          Container(
            width: Get.width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(27),
                bottomLeft: Radius.circular(27),
              ),
              color: ColorResources.blue1D3,
            ),
            child: Padding(
              padding:
                  EdgeInsets.only(top: 40, bottom: 20, left: 25, right: 25),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                      onTap: () {
                        Get.to(SearchScreen());
                      },
                      child: SvgPicture.asset(Images.search,
                          color: ColorResources.white)),
                  InkWell(
                    onTap: () {
                      Get.to(ScanQrCodeScreen());
                    },
                    child: SvgPicture.asset(Images.scanIcon),
                  ),
                  InkWell(
                      onTap: () {
                        Get.to(NotificationScreen());
                      },
                      child: SvgPicture.asset(Images.notificationIcon)),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 100, left: 20, right: 20),
            child: ScrollConfiguration(
              behavior: MyBehavior(),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 210,
                      width: Get.width,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        image: DecorationImage(
                          image: AssetImage(Images.bannerImage),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    boldText("Transfer Money", ColorResources.blue1D3, 20),
                    SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        commonColumn(
                          Images.phoneTransfer,
                          "Phone \nnumber",
                          () {
                            Get.to(MobileNumberScreen());
                          },
                        ),
                        commonColumn(
                          Images.bankTransfer,
                          "Bank \ntransfer",
                          () {
                            Get.to(EnterRecipientDetailScreen());
                          },
                        ),
                        commonColumn(
                          Images.selfTransfer,
                          "Self-\ntransfer",
                          () {
                            Get.to(SelfTrasferScreen());
                          },
                        ),
                        commonColumn(
                          Images.bankTransfer,
                          "Check \nBank Balance",
                          () {
                            Get.to(BankBalanceScreen());
                          },
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    boldText("Payment Categories", ColorResources.blue1D3, 20),
                    SizedBox(height: 20),
                    LayoutBuilder(
                      builder: (context, constraints) => GridView.count(
                        padding: EdgeInsets.only(top: 5, left: 2, right: 2),
                        childAspectRatio:
                            MediaQuery.of(context).size.aspectRatio * 3 / 2.6,
                        shrinkWrap: true,
                        crossAxisCount: 4,
                        crossAxisSpacing: 20,
                        mainAxisSpacing: 20,
                        physics: NeverScrollableScrollPhysics(),
                        children: List.generate(
                          paymentCategoryList.length,
                          (index) => Column(
                            children: [
                              InkWell(
                                onTap: paymentCategoryList[index]["onTap"],
                                child: Container(
                                  height: 65,
                                  width: 65,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: ColorResources.greyF1F,
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 2,
                                        offset: Offset(0, 0),
                                        spreadRadius: 0,
                                        color: ColorResources.black
                                            .withOpacity(0.25),
                                      ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(15),
                                    child: SvgPicture.asset(
                                        paymentCategoryList[index]["image"]),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5),
                              regularText(paymentCategoryList[index]["text"],
                                  ColorResources.grey6B7, 14, TextAlign.center),
                            ],
                          ),
                        ).toList(),
                      ),
                    ),
                    SizedBox(height: 20),
                    boldText("People", ColorResources.blue1D3, 20),
                    SizedBox(height: 20),
                    SizedBox(
                      height: 95,
                      width: Get.width,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: peopleList.length,
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemBuilder: (context, index) => Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(right: 30),
                              child: InkWell(
                                onTap: peopleList[index]["onTap"],
                                child: CircleAvatar(
                                  radius: 35,
                                  backgroundColor: ColorResources.white,
                                  backgroundImage:
                                      AssetImage(peopleList[index]["image"]),
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                            Padding(
                              padding: EdgeInsets.only(right: 30),
                              child: regularText(peopleList[index]["text"],
                                  ColorResources.grey6B7, 14),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    boldText(
                        "Businesses and Bills", ColorResources.blue1D3, 20),
                    SizedBox(height: 20),
                    LayoutBuilder(
                      builder: (context, constraints) => GridView.count(
                        padding: EdgeInsets.only(top: 5, left: 2, right: 2),
                        childAspectRatio:
                            MediaQuery.of(context).size.aspectRatio * 3 / 2.6,
                        shrinkWrap: true,
                        crossAxisCount: 4,
                        crossAxisSpacing: 20,
                        mainAxisSpacing: 20,
                        physics: NeverScrollableScrollPhysics(),
                        children: List.generate(
                          businessAndBillsList.length,
                          (index) => Column(
                            children: [
                              InkWell(
                                onTap: businessAndBillsList[index]["onTap"],
                                child: Image.asset(
                                  businessAndBillsList[index]["image"],
                                ),
                              ),
                              SizedBox(height: 5),
                              regularText(businessAndBillsList[index]["text"],
                                  ColorResources.grey6B7, 14, TextAlign.center),
                            ],
                          ),
                        ).toList(),
                      ),
                    ),
                    SizedBox(height: 20),
                    boldText("Promotions", ColorResources.blue1D3, 20),
                    SizedBox(height: 20),
                    LayoutBuilder(
                      builder: (context, constraints) => GridView.count(
                        padding: EdgeInsets.only(
                            top: 5, left: 2, right: 2, bottom: 2),
                        childAspectRatio:
                            MediaQuery.of(context).size.aspectRatio * 3 / 0.6,
                        shrinkWrap: true,
                        crossAxisCount: 2,
                        crossAxisSpacing: 15,
                        mainAxisSpacing: 15,
                        physics: NeverScrollableScrollPhysics(),
                        children: List.generate(
                          promotionList.length,
                          (index) => InkWell(
                            onTap: promotionList[index]["onTap"],
                            child: Container(
                              height: 55,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: ColorResources.white,
                                boxShadow: [
                                  BoxShadow(
                                    blurRadius: 2,
                                    offset: Offset(0, 0),
                                    spreadRadius: 0,
                                    color:
                                        ColorResources.black.withOpacity(0.25),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(right: 15),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    SvgPicture.asset(
                                        promotionList[index]["image"]),
                                    mediumText(promotionList[index]["text"],
                                        ColorResources.blue1D3, 16),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ).toList(),
                      ),
                    ),
                    SizedBox(height: 110),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
