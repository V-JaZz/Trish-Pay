import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:gpayapp/HomeScreen/SelectProviderBillScreens/select_provider_bill_screen.dart';
import 'package:gpayapp/Utils/colors.dart';
import 'package:gpayapp/Utils/common_widget.dart';
import 'package:gpayapp/Utils/images.dart';
import 'package:gpayapp/main.dart';

class SelectProviderScreen extends StatelessWidget {
  SelectProviderScreen({Key? key}) : super(key: key);

  final List<Map> selectProviderList = [
    {
      "image": Images.airtelCard2,
      "text": "Airtel Digital TV",
    },
    {
      "image": Images.dishTvImage,
      "text": "Dish TV",
    },
    {
      "image": Images.sunDirectImage,
      "text": "Sun Direct",
    },
    {
      "image": Images.tataPlayImage,
      "text": "Tata Play (Formerly Tatasky)",
    },
    {
      "image": Images.d2hImage,
      "text": "D2H",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.white,
      appBar: AppBar(
        backgroundColor: ColorResources.white,
        automaticallyImplyLeading: false,
        centerTitle: true,
        elevation: 0,
        leading: Padding(
          padding: EdgeInsets.only(left: 18,top: 8,bottom: 8),
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: ColorResources.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ColorResources.greyE5E, width: 1),
              ),
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_outlined,
                  color: ColorResources.black,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: boldText("Select Provider", ColorResources.black, 20),
      ),
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: ListView.builder(
          itemCount: selectProviderList.length,
          shrinkWrap: true,
          padding: EdgeInsets.only(left: 20, right: 20, top: 25),
          itemBuilder: (context, index) => Padding(
            padding: EdgeInsets.only(bottom: 15),
            child: InkWell(
              onTap: () {
                Get.to(SelectProviderBillScreen());
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: ColorResources.white,
                  border: Border.all(color: ColorResources.greyE5E, width: 1),
                ),
                child: ListTile(
                  leading: Padding(
                    padding: EdgeInsets.only(top: 8, bottom: 8),
                    child: Image.asset(
                      selectProviderList[index]["image"],
                    ),
                  ),
                  title: boldText(selectProviderList[index]["text"],
                      ColorResources.blue1D3, 16),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
