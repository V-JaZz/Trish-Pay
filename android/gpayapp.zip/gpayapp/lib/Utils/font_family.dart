class TextFontFamily{
static String  ROBOTO_BOLD = "RobotoBold";
static String  ROBOTO_REGULAR = "RobotoRegular";
static String  ROBOTO_LIGHT = "RobotoLight";
static String  ROBOTO_BLACK = "RobotoBlack";
static String  ROBOTO_MEDIUM = "RobotoMedium";
}